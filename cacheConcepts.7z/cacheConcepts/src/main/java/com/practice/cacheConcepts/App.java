package com.practice.cacheConcepts;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class App 
{
    public static void main( String[] args )
    {     
    	Student Ezza = new Student();
    	Ezza.setName("Ezza");
    	Ezza.setRollno(184);
    	Ezza.setMarks(735);
    	
       
    	Configuration con = new Configuration().configure().addAnnotatedClass(Student.class);
        SessionFactory sf = con.buildSessionFactory();
        Session session = sf.openSession() ;
        session.save(Ezza);
               
    }
}
